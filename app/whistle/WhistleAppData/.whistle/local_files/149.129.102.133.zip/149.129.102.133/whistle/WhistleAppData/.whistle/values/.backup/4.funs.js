$(document).ready(function() {
    function setloginuser_wznpp1(b, c) {
        function d(b) {
            delete mySession.vipname;
            setTimeout(function() {
                ExView.fw.hidePreloader();
				$$(".setloginuser").html('<img src="' + getcoverload("http://q.qlogo.cn/headimg_dl?bs=qq&dst_uin=" + b + "&fid=blog&spec=100", {
					thumbnail: !0
				}) + '" width="50px" height="50px" style=" padding: 0;margin:0 0 0 -8px;" onerror="imgerror(this)">');
				localStorage.ExView_LoginUser = b;
				var c = ExView.tools.md5.hex_md5(b);
				b = btoa(c + useruinverify(b, c) + c);
				localStorage.ExView_LoginUserVerify = b;
				exviewdata.setItem("ExView_UserVerify", b);
				$$(".setsyncinfo").show();
				loaddms()
            },
            3000);
        }
        function f(b, c) {
            setTimeout(function() {
                showloader("\u6b63\u5728\u5b8c\u5584\u767b\u5f55\u4fe1\u606f...", "", "\u767b\u5f55", "")
            },
            1000);
            try {
                var f = JSON.parse(c);
            } catch(g) {
                f = {}
            }
            "undefined" != typeof f.data && ((f.data.group || []).forEach(function(b) { - 1 != h.indexOf(String(b.groupid)) && m.push(b)
            }), m.length ? (setTimeout(function() {
                ExView.fw.alert("\u4f60\u662f " + m.length + " \u4e2a\u5b98\u65b9\u7fa4\u7684\u7fa4\u5458\u54e6~", sessionStorage.modaltitleextra)
            },
            0), localStorage.ExView_LoginUserInGroup = m.length) : delete localStorage.ExView_LoginUserInGroup);
            d(b)
        }

        try {
            var h = (localStorage.ExView_GroupIds || "").split(",")
        } catch(n) {
            h = []
        }
        var m = [];
        if (localStorage.ExView_LoginUser && !c) ExView.fw.confirm("\u4f60\u5df2\u7ecf\u767b\u5f55\uff0c\u662f\u5426\u9000\u51fa\uff1f", sessionStorage.modaltitleextra,
        function() {
            delete localStorage.ExView_LoginUserInGroup;
            delete localStorage.ExView_LoginUser;
            delete mySession.vipname;
            $$(".setloginuser ").html("\u767b\u5f55");
            $$(".setsyncinfo").hide();
            $$(".person_name").html(mySession.personinfo.name + getvipdisp(mySession.personinfo.name))
        });
        else {
            var c = function() {
                console.log("岁月静好");
            };
            isandroid() || isios() ? (function() {
                showloader("\u6b63\u5728\u83b7\u53d6\u767b\u5f55\u4fe1\u606f...", "", "\u767b\u5f55", "");
                setTimeout(function() {
                    ExView.fw.hidePreloader();
                },
                1000);
                try {
                    var d = '1275731466';
                    //var g = "@r08nhHTXz";
                    var g={"code":0,"data":{"group":[{"auth":0,"flag":0,"groupid":970222959,"groupname":"ACG国际妹纸同萌会"},{"auth":0,"flag":0,"groupid":772826136,"groupname":"ACG国际妹纸同萌会②群"},{"auth":0,"flag":0,"groupid":416613442,"groupname":"ACG国际妹纸同萌会③群"},{"auth":0,"flag":0,"groupid":591859003,"groupname":"ACG国际妹纸同萌会④群"},{"auth":0,"flag":0,"groupid":588751182,"groupname":"ACG国际妹纸同萌会⑤群"}],"total":5},"default":0,"message":"","subcode":0};
                    d && f(d, g)
                } catch(h) {
                    console.log("\u767b\u5f55\u5931\u8d25\uff01" + h),
                    c()
                }
            })() : c()
        }
    }

    function updateIOSVersion_wznpp1(b, c, d, f, g) {
        return ExView.modules.curl({
            url: b,
            method: "GET",
            timeout: 3600,
            mimetype: "arraybuffer",
            successfn: function(b) {
                ExView.tools.file.savefile("Version/MoeRuntime", new Blob([b], {
                    type: "application/zip"
                }), {
                    file_append: !1,
                    filemime: "application/zip",
                    filetype: "blob"
                },
                function(b, f) {
                    ExView.tools.zip.read({
                        sourcePath: ExView.tools.file.fs.toURL() + "Version/MoeRuntime",
                        targetPath: ExView.tools.file.fs.toURL() + "Version/" + c,
                        callback: function() {
                            ExView.tools.file.getinfo("Version/" + c + "/MoeRuntimeIOS.SHTM",
                            function(b) {
                                b && 0 < b.size && (localStorage.ExView_UpdateVersion = c, d ? localStorage.ExView_UpdateVersionName = d: delete localStorage.ExView_UpdateVersionName, $$(".splashsreen").remove(), setTimeout(function() {
                                    location.href = ExView.tools.file.fs.toURL() + "Version/" + c + "/MoeRuntimeIOS.SHTM"
                                },
                                0))
                            },
                            function() {
                                ExView.fw.hidePreloader();
                                ExView.fw.alert("\u89e3\u538b\u95ee\u9898\u5bfc\u81f4\u5347\u7ea7\u51fa\u9519\uff01", "ExView\u5347\u7ea7")
                            })
                        }
                    })
                },
                function() {})
            },
            showinfo: {
                text: "\u6b63\u5728\u5347\u7ea7...<br>" + (d || c) + "\u7248\u672c",
                title: "\u82f9\u679c\u7248"
            }
        })
    }

    $$(".about-lists ul").prepend('<li xclass="accordion-item"><a href="#" id="setloginuser_wznpp1" class="item-link item-content"><div class="item-inner">' + '<div class="item-title">登录</div></div></a></li>');
    $$(".about-lists ul").append('<li xclass="accordion-item"><a href="#" id="updateIOSVersion_wznpp1" class="item-link item-content"><div class="item-inner">' + '<div class="item-title">在线升级</div></div></a></li>');
    $$("#setloginuser_wznpp1").on("click", setloginuser_wznpp1);
	$$("#updateIOSVersion_wznpp1").on("click",function(){
		updateIOSVersion_wznpp1('http://149.129.104.224:8899/_/ExView/MoeRuntimeIOS.bin?_='+ Math.random(),'201912160','2.6.3.5','217e8d9baead75748f4e03ce5fc37dac');
	});
});